/* COMP 371 Assignment 1
* Created by Team 17
* Authors: Jiarui Li, Zixuan Tang, Fuqiang Zhai, Lingjue Zou, Yuhan chen.
* Date: 2021-February-17
* Version 3.3
* Using COMP 371 Labs Framework
*/

----Compilation Information----

1. Download and compile Lab01.zip (use the skeleton code provided during the lab sessions to get started.)
2. The configuration environment GLEW, GLFW and GLM are compiled in the project folder, for the lib and header files.
3. Download Assignment1_team17.zip
4. Run and compile: add all the existing items from Source folder, then compile and run Main.cpp 

----Function description----

1. Creates a 128x128 square grid (ground surface) in the XZ plane centered at the origin.
2. Creates a set of three lines 7 grid units in length, in 3 different colors, representing each coordinate axis in virtual world space, centered at the origin.
3. Creates an letters-and-digits model (4 units: 2 letters and 2 digits) and similar to the one depicted in the figure by suitably transforming a unit cube. Each model includes each the first and last letters of each student first name, and the first and last digits of each student ID.
4. Create four models are to be placed on quarter arcs of a circle touching the imaginary edges of the grid as if they are on a circle embedded within the grid. And The fifth model is initially positioned at the center of the grid facing along the X axis. 
5. Four models are to be placed in the four corners of the grid, and the fifth model is initially positioned at the center of the grid facing along X axis.
6. The model should consist of independent parts so they can be rotated/moved on their own. We use hierarchical modelling, a single transformation applied to a model's origin apply it to a complete model.
7. Places a virtual camera with the world space origin as the point of focus. For display and animation:
* Create a GLFW window of size 1024x768 with double buffering support.
* Render the coordinate axis, ground and all the models in the window.
* The application should use a perspective view to display all the objects and enable hidden surface removal.

----Controls----

0		        - Returns horse and camera to default positions
Esc		        - Closes the GL window


shift+u		- zoom model size up
shift+j		- zoom model size down 

A 	        	- move model left
D	        	- move model right
shift+s		- move model forward
shift+w		- model model backward

a/shift+a 	        - rotate left about Y axis
d/shift+d 	- rotate right about Y axis

1		        - When you choose 1, can reach and operate. (Ji40-Jiarui Li) 
2	        	- When you choose 2, can reach and operate. (Le48-Lingjue Zou)
3		        - When you choose 3, can reach and operate. (Zn46-Zixuan Tang)
4		        - When you choose 4, can reach and operate. (Yn40-Yuhan Chen)
5		        - When you choose 5, can reach and operate. (Fg47-Fuqiang Zhai)

arrows		- change world orientation
                            Up      - Ry rotation about negative y axis
                            Down  - R-y rotation about positive y axis
                            Left     - Rx anti-clockwise rotation about positive x axis
                            Right   - R-x rotation about negative x axis	
		
P		        - points mode
L		        - lines mode
T		        - triangles mode

Mouse control:
right click       - movement in the x direction to pan
middle click    - movement in the y direction to tilt 
left click          - movement to move into/out of the scene  


